package de.unibonn.iai.eis.linda.querybuilder.output;

import de.unibonn.iai.eis.linda.querybuilder.classes.RDFClass;

public class ClassPropertyOutput {
	public RDFClass rdfClass;
	
	public ClassPropertyOutput(RDFClass rdfClass){
		this.rdfClass = rdfClass;
	}
}
