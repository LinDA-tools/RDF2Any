package de.unibonn.iai.eis.linda.helper.output;

public class ResultOK {
	public String result;
	
	public ResultOK(){
		this.result = "OK";
	}
}
