
public class resourceExample {

}
