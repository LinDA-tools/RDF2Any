
public class testResourceExample {

}
